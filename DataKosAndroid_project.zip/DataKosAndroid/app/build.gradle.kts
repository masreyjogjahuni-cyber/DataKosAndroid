plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.jogjahuni.datakos"; compileSdk = 35
 defaultConfig { applicationId = "com.jogjahuni.datakos"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
