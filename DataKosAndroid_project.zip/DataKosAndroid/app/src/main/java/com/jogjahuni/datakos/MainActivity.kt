package com.jogjahuni.datakos

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Kos(var id:String="",var kode:String="",var wa1:String="",var wa2:String="",var maps:String="",var harga:String="",var harga2:String="",var url:String="",var catatan:String="")

class MainActivity: Activity(){
 private val PICK=10; private val CREATE=11; private var uri:Uri?=null; private val data=mutableListOf<Kos>(); private lateinit var list:LinearLayout; private lateinit var search:EditText
 override fun onCreate(b:Bundle?){super.onCreate(b);ui();getPreferences(0).getString("uri",null)?.let{uri=Uri.parse(it);read()};render()}
 private fun ui(){val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(12,8,12,8);root.setBackgroundColor(Color.rgb(16,17,20));val title=TextView(this);title.text="DATA KOS";title.textSize=20f;title.setTextColor(Color.WHITE);root.addView(title,LinearLayout.LayoutParams(-1,44));search=EditText(this);search.hint="Cari kode, WA, catatan...";search.setSingleLine();search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);root.addView(search,LinearLayout.LayoutParams(-1,48));search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?) {}});val bar=LinearLayout(this);fun b(t:String,f:()->Unit){val x=Button(this);x.text=t;x.setOnClickListener{f()};bar.addView(x,LinearLayout.LayoutParams(0,50,1f))};b("+ TAMBAH"){form(null)};b("BUKA JSON"){pick()};b("BACKUP"){create()};root.addView(bar);list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;val sv=ScrollView(this);sv.addView(list);root.addView(sv,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)}
 private fun pick(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE)},PICK)}
 private fun create(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/json";putExtra(Intent.EXTRA_TITLE,"data-kos.json")},CREATE)}
 override fun onActivityResult(r:Int,c:Int,i:Intent?){super.onActivityResult(r,c,i);if(c!=RESULT_OK||i?.data==null)return;uri=i.data;getPreferences(0).edit().putString("uri",uri.toString()).apply();if(r==PICK)read() else write()}
 private fun read(){try{val t=contentResolver.openInputStream(uri!!)!!.bufferedReader().use{it.readText()};data.clear();val a=JSONArray(t);for(j in 0 until a.length()){val o=a.getJSONObject(j);data.add(Kos(o.optString("id"),o.optString("kode"),o.optString("wa1"),o.optString("wa2"),o.optString("maps"),o.optString("harga"),o.optString("harga2"),o.optString("url"),o.optString("catatan")))};render();toast("JSON dibuka")}catch(e:Exception){toast("Gagal membaca JSON")}}
 private fun json():String{val a=JSONArray();data.forEach{k->a.put(JSONObject().apply{put("id",k.id);put("kode",k.kode);put("wa1",k.wa1);put("wa2",k.wa2);put("maps",k.maps);put("harga",k.harga);put("harga2",k.harga2);put("url",k.url);put("catatan",k.catatan)})};return a.toString(2)}
 private fun write(){try{contentResolver.openOutputStream(uri!!,"wt")!!.bufferedWriter().use{it.write(json())};toast("JSON tersimpan")}catch(e:Exception){toast("Gagal menyimpan")}}
 private fun save(){if(uri!=null)write()else toast("Buka data-kos.json dulu")}
 private fun render(){list.removeAllViews();val q=search.text.toString().lowercase();data.filter{"${it.kode} ${it.wa1} ${it.wa2} ${it.catatan}".lowercase().contains(q)}.forEach{k->val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.setPadding(10,8,10,8);val t=TextView(this);t.text="${k.kode.ifBlank{"Tanpa kode"}}  •  ${k.harga.ifBlank{"Harga belum diisi"}}";t.textSize=16f;t.setTextColor(Color.WHITE);val s=TextView(this);s.text="${k.catatan}\n${k.wa1}";s.textSize=13f;s.setTextColor(Color.LTGRAY);c.addView(t);c.addView(s);c.setOnClickListener{detail(k)};list.addView(c);val v=View(this);v.setBackgroundColor(Color.DKGRAY);list.addView(v,LinearLayout.LayoutParams(-1,1))};val n=TextView(this);n.text="${data.size} data";n.setTextColor(Color.GRAY);list.addView(n)}
 private fun detail(k:Kos){AlertDialog.Builder(this).setTitle(k.kode).setMessage("WA: ${k.wa1}\nWA 2: ${k.wa2}\nHarga: ${k.harga}\nHarga 2: ${k.harga2}\nMaps: ${k.maps}\nURL/Video: ${k.url}\nCatatan: ${k.catatan}").setPositiveButton("EDIT"){_,_->form(k)}.setNegativeButton("HAPUS"){_,_->confirmDelete(k)}.setNeutralButton("TUTUP",null).show()}
 private fun confirmDelete(k:Kos){AlertDialog.Builder(this).setTitle("Hapus ${k.kode}?").setNegativeButton("Batal",null).setPositiveButton("Hapus"){_,_->data.remove(k);save();render()}.show()}
 private fun form(old:Kos?){val names=arrayOf("Kode","WA 1","WA 2","Maps","Harga","Harga 2","URL / Video","Catatan");val es=names.map{EditText(this).apply{hint=it;setTextColor(Color.WHITE);setHintTextColor(Color.GRAY)}};old?.let{listOf(it.kode,it.wa1,it.wa2,it.maps,it.harga,it.harga2,it.url,it.catatan).forEachIndexed{n,v->es[n].setText(v)}};val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(20,0,20,0);es.forEach{box.addView(it,LinearLayout.LayoutParams(-1,48))};AlertDialog.Builder(this).setTitle(if(old==null)"Tambah Kos" else "Edit Kos").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan"){_,_->val k=old?:Kos(id=System.currentTimeMillis().toString());val v=es.map{it.text.toString()};k.kode=v[0];k.wa1=v[1];k.wa2=v[2];k.maps=v[3];k.harga=v[4];k.harga2=v[5];k.url=v[6];k.catatan=v[7];if(old==null)data.add(k);save();render()}.show()}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
