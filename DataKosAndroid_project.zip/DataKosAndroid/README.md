# Data Kos Android

Aplikasi Android offline untuk data kos. Data disimpan sebagai file `data-kos.json` yang kamu pilih di penyimpanan HP menggunakan pemilih file Android.

Fitur: tambah, edit, hapus, cari, buka JSON, simpan langsung ke JSON, dan backup JSON.

Cara build: buka folder ini di Android Studio -> tunggu Gradle Sync -> Build > Build APK(s).
